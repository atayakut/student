<?php
include('config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_name = $_POST['student_name'];
    $student_id = $_POST['student_id'];
    $student_grade = $_POST['student_grade'];

    $sql = "INSERT INTO students (student_name, student_id, student_grade) VALUES ('$student_name', '$student_id', '$student_grade')";

    if ($conn->query($sql) === TRUE) {
        echo "Student record added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}
?>
