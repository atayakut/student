<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>info of students?</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Girilen Öğrenci Bilgileri</h1>

        <?php
        
        $servername = "localhost";
        $username = "Ata"; 
        $password = "georgian"; 
        $dbname = "MySQL"; 

        $conn = new mysqli($servername, $username, $password, $dbname);

        
        if ($conn->connect_error) {
            die("no connection: " . $conn->connect_error);
        }

        
        $sql = "SELECT * FROM students";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table><tr><th>student name</th><th>student number</th><th>Not</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row["student_name"] . "</td><td>" . $row["student_id"] . "</td><td>" . $row["student_grade"] . "</td></tr>";
            }
            echo "</table>";
        } else {
            echo "there is no info yet.";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
