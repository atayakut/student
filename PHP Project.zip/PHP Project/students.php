<?php
include('config.php');

$sql = "SELECT * FROM students";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "ID: " . $row["student_id"]. " - Name: " . $row["student_name"]. " - Grade: " . $row["student_grade"]. "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?>
